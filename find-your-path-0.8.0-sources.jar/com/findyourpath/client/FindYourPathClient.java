package com.findyourpath.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPlayerBlockBreakEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.CraftingScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Difficulty;
import net.minecraft.world.item.ItemStack;

import com.findyourpath.client.Quests.Role;
import com.findyourpath.client.Quests.Step;

public class FindYourPathClient implements ClientModInitializer {
	public static final String MOD_ID = "findyourpath";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static KeyMapping openKey;
	private static SaveData save;
	private static final Tracker tracker = new Tracker();
	private static final Random random = new Random();

	// current world + quest
	private static String worldKey;
	private static Role role;
	private static int stepIndex;
	private static boolean zombieSpawnedForStep;
	private static boolean hintShown;           // "Show me how" tapped on a recall step
	private static Role returnRole;             // main quest to come back to after a side lesson
	private static int returnStep;

	// timers (ticks)
	private static final int FLASH_TICKS = 36, PENDING = -2;
	private static int lastLogs = -1;
	private static boolean died;
	private static int checkTimer, popupTimer = -1, flashTimer, tipTimer, nextTipAt = 1200;

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitializeClient() {
		save = SaveData.load();

		openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.findyourpath.open",
				InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, KeyMapping.Category.register(id("main"))));

		ClientTickEvents.END_CLIENT_TICK.register(FindYourPathClient::tick);
		ClientTickEvents.END_CLIENT_TICK.register(BlockGuide::tick);
		ClientPlayerBlockBreakEvents.AFTER.register((world, player, pos, state) -> BlockGuide.onBlockMined(state));
		HudElementRegistry.attachElementAfter(VanillaHudElements.OVERLAY_MESSAGE, id("hint"), FindYourPathClient::drawHud);

		// helper panel next to the crafting grid
		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
			if (screen instanceof InventoryScreen || screen instanceof CraftingScreen) {
				ScreenEvents.afterExtract(screen).register((s, g, mx, my, delta) -> {
					if (role != null) CraftingGuide.draw(s, g, role, stepIndex, tracker, flashTimer > 0);
				});
			}
		});
	}

	// ------------------------------------------------------------------ quest state
	public static Role currentRole() { return role; }
	public static int currentStepIndex() { return stepIndex; }
	static Step currentStep() { return role == null ? null : role.steps().get(stepIndex); }
	public static boolean level1Done() { return save.level1Done; }
	public static boolean hintShown() { return hintShown; }
	static void showHint() { hintShown = true; }
	public static Tracker tracker() { return tracker; }
	public static Role returnRole() { return returnRole; }
	static boolean blockGuideMuted(String key) { return save.blockGuideMuted.contains(key); }
	static void muteBlockGuide(String key) { save.blockGuideMuted.add(key); save.save(); }

	/** Start a side lesson; the main quest resumes when it's done. */
	static void startSideLesson(Role side) {
		if (role != null && !Quests.isSideLesson(role)) { returnRole = role; returnStep = stepIndex; }
		role = side;
		stepIndex = 0;
		beginStep();
		persist();
	}

	/** Skip the current step (still counts toward unlocking). */
	static void skipStep() { advance(); }

	static void start(Role r) {
		Minecraft mc = Minecraft.getInstance();
		if (role != null) Tracker.removeTrainingZombie(mc);
		returnRole = null;
		role = r;
		stepIndex = 0;
		beginStep();
		persist();
	}

	static void abandon() {
		Tracker.removeTrainingZombie(Minecraft.getInstance());
		role = null;
		returnRole = null;
		stepIndex = 0;
		popupTimer = -1;
		persist();
	}

	private static void beginStep() {
		tracker.resetStep();
		zombieSpawnedForStep = false;
		hintShown = false;
	}

	/** After the player dismisses a step tablet. Spawns the Training Zombie when that's the step. */
	static void onStepScreenClosed() {
		Step st = currentStep();
		Minecraft mc = Minecraft.getInstance();
		if (st != null && st.title().startsWith("Defeat the Training Zombie") && !zombieSpawnedForStep
				&& mc.level != null && mc.level.getDifficulty() != Difficulty.PEACEFUL) {
			Tracker.spawnTrainingZombie(mc);
			zombieSpawnedForStep = true;
		}
	}

	private static void advance() {
		Minecraft mc = Minecraft.getInstance();
		stepIndex++;
		flashTimer = FLASH_TICKS;
		if (stepIndex >= role.steps().size()) {
			Role done = role;
			mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0f));
			if (Quests.isSideLesson(done) && returnRole != null) {
				// back to the main quest
				role = returnRole;
				stepIndex = returnStep;
				returnRole = null;
				beginStep();
				persist();
				popupTimer = -1;
				Flow.sideLessonDone(done);
				return;
			}
			role = null;
			stepIndex = 0;
			if (done == Quests.FIRST_DAY) save.level1Done = true;
			persist();
			Flow.complete(done);
			return;
		}
		mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f));
		beginStep();
		persist();
		// in the crafting screen the guide panel shows the next step live; the tablet waits until it's closed
		popupTimer = CraftingGuide.isCraftingScreen(mc.gui.screen()) ? PENDING : FLASH_TICKS - 4;
	}

	private static void persist() {
		if (worldKey == null) return;
		if (role == null) save.worlds.remove(worldKey);
		else {
			SaveData.WorldProgress p = new SaveData.WorldProgress();
			p.role = role.id();
			p.step = stepIndex;
			p.returnRole = returnRole == null ? null : returnRole.id();
			p.returnStep = returnStep;
			save.worlds.put(worldKey, p);
		}
		save.save();
	}

	private static String computeWorldKey(Minecraft mc) {
		try {
			var server = mc.getSingleplayerServer();
			if (server != null) return "sp:" + server.getWorldData().getLevelName();
			if (mc.getCurrentServer() != null) return "mp:" + mc.getCurrentServer().ip;
		} catch (Exception ignored) {
		}
		return "default";
	}

	// ------------------------------------------------------------------ tick
	private static void tick(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			worldKey = null;
			return;
		}
		if (worldKey == null) { // just joined a world: load its progress
			worldKey = computeWorldKey(mc);
			SaveData.WorldProgress p = save.worlds.get(worldKey);
			role = p == null ? null : Quests.role(p.role);
			stepIndex = role == null ? 0 : Math.min(p.step, role.steps().size() - 1);
			returnRole = p == null || p.returnRole == null ? null : Quests.role(p.returnRole);
			returnStep = p == null ? 0 : p.returnStep;
			beginStep();
			popupTimer = -1;
		}
		tracker.bind(mc.player);

		while (openKey.consumeClick()) {
			if (mc.gui.screen() == null) Flow.welcome();
		}

		if (flashTimer > 0) flashTimer--;

		if (role != null) {
			tracker.tick();
			// log pop-ups while collecting wood
			Step cur = currentStep();
			if (cur != null && cur.title().equals("Get 3 logs")) {
				int logs = tracker.countLogs();
				if (lastLogs >= 0 && logs > lastLogs && logs <= 3) {
					int left = 3 - logs;
					mc.gui.toastManager().addToast(new ProgressToast(net.minecraft.world.item.Items.OAK_LOG,
							logs == 1 ? "Got a log!" : "Got another log!",
							logs + " of 3" + (left > 0 ? "  \u00B7  " + left + " to go" : "  \u00B7  done!"), role.color()));
				}
				lastLogs = logs;
			} else {
				lastLogs = -1;
			}
			if (popupTimer == PENDING && mc.gui.screen() == null) popupTimer = 8;
			if (popupTimer > 0 && --popupTimer == 0) {
				popupTimer = -1;
				if (mc.gui.screen() == null) Flow.currentStep();
			}
			boolean canCheck = mc.gui.screen() == null || CraftingGuide.isCraftingScreen(mc.gui.screen());
			// (skippable/recall steps check the same way; skipping is a button on the step screen)
			if (popupTimer < 0 && canCheck && ++checkTimer >= 5) {
				checkTimer = 0;
				Step st = currentStep();
				if (st != null && st.check().test(tracker)) advance();
			}
		}

		// random tips, only while actually playing
		if (mc.gui.screen() == null && ++tipTimer >= nextTipAt) {
			tipTimer = 0;
			nextTipAt = 2400 + random.nextInt(3600);
			showRandomTip(mc);
		}

		// first death: explain that you drop everything
		if (mc.gui.screen() instanceof net.minecraft.client.gui.screens.DeathScreen) died = true;
		else if (died && mc.gui.screen() == null && mc.player.isAlive()) {
			died = false;
			lastLogs = -1;
			if (!save.seenDeathInfo) {
				save.seenDeathInfo = true;
				save.save();
				Flow.firstDeath();
			}
		}
	}

	private static void showRandomTip(Minecraft mc) {
		List<Quests.Tip> unseen = new ArrayList<>();
		for (Quests.Tip t : Quests.TIPS) if (!save.seenTips.contains(t.title())) unseen.add(t);
		if (unseen.isEmpty()) return;
		Quests.Tip tip = unseen.get(random.nextInt(unseen.size()));
		save.seenTips.add(tip.title());
		save.save();
		mc.gui.toastManager().addToast(new TipToast(tip));
	}

	// ------------------------------------------------------------------ HUD line above the hotbar
	private static void drawHud(GuiGraphicsExtractor g, net.minecraft.client.DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) return;
		Font font = mc.font;
		int w = g.guiWidth(), h = g.guiHeight();

		if (flashTimer > 0) {
			int s = 3, cw = Ui.checkW(s), ch = Ui.checkH(s);
			int pw = Math.max(cw, font.width("STEP DONE")) + 40, ph = ch + 40;
			int px = (w - pw) / 2, py = h / 2 - ph - 20;
			int accent = role != null ? role.color() : Ui.GREEN;
			Ui.smallPanel(g, px, py, pw, ph, accent);
			float progress = (FLASH_TICKS - flashTimer) / 8f;
			Ui.check(g, px + (pw - cw) / 2, py + 12, s, progress, Ui.GREEN);
			Ui.textCentered(g, font, "STEP DONE", px + pw / 2, py + ph - 16, Ui.WHITE);
		}

		String line;
		Step st = currentStep();
		if (st != null) {
			line = role.name() + ", Step " + (stepIndex + 1) + " of " + role.steps().size() + ": " + st.bar() + progressSuffix(st);
		} else {
			line = "Press " + openKey.getTranslatedKeyMessage().getString() + " to open Find Your Path";
		}
		int color = st != null ? role.color() : Ui.GOLD;
		int tw = font.width(line);
		int x = (w - tw) / 2, y = h - 72;
		g.fill(x - 3, y - 2, x + tw + 3, y + 10, 0x66000000);
		g.text(font, line, x, y, color, true);
	}

	private static String progressSuffix(Step st) {
		if (st.title().equals("Travel 300 blocks")) return "  (" + Math.min(300, (int) tracker.travelled()) + "/300)";
		if (st.title().equals("Be inside when night falls")) {
			int m = tracker.minutesToNight();
			return m > 0 ? "  (night in ~" + m + " min)" : "  (it's night: get under a roof!)";
		}
		if (st.title().equals("Mine 3 cobblestone")) return "  (" + Math.min(3, tracker.count(net.minecraft.world.item.Items.COBBLESTONE)) + "/3)";
		if (st.title().equals("Gather 20 cobblestone")) return "  (" + Math.min(20, tracker.count(net.minecraft.world.item.Items.COBBLESTONE)) + "/20)";
		if (st.title().equals("Build stone walls")) return "  (" + Math.min(16, tracker.cobblePlaced()) + "/16)";
		if (st.title().equals("Climb up high")) return "  (height " + (int) tracker.height() + "/100)";
		if (st.title().equals("Dig some dirt")) return "  (" + Math.min(10, tracker.count(net.minecraft.world.item.Items.DIRT)) + "/10)";
		if (st.title().equals("Build walls")) return "  (" + Math.min(8, tracker.dirtPlaced()) + "/8)";
		if (st.title().equals("Get 3 logs")) return "  (" + Math.min(3, tracker.countLogs()) + "/3)";
		return "";
	}

}
